package com.clipper.studio;
import java.util.*;
import java.util.regex.*;

final class Planner {
    record Cue(long start, long end, String text) {}
    record Clip(long start, long end, int score) {}
    static final Pattern TIME = Pattern.compile("(\\d{1,3}):(\\d{2}):(\\d{2})[,.](\\d{3})");
    static long ms(String s) {
        Matcher m=TIME.matcher(s); if(!m.find()) throw new IllegalArgumentException("Timestamp SRT tidak valid");
        return (((Long.parseLong(m.group(1))*60+Long.parseLong(m.group(2)))*60+Long.parseLong(m.group(3)))*1000+Long.parseLong(m.group(4)));
    }
    static List<Cue> parse(String input) {
        List<Cue> out=new ArrayList<>();
        for(String b:input.replace("\ufeff", "").replace("\r", "").trim().split("\\n[ \\t]*\\n+")) {
            String[] l=b.split("\\n");
            for(int i=0;i<l.length;i++) if(l[i].contains("-->")) {
                try {
                    String[] t=l[i].split("-->"); long a=ms(t[0]),z=ms(t[1]);
                    String text=String.join(" ",Arrays.copyOfRange(l,i+1,l.length)).replaceAll("<[^>]+>", "").trim();
                    if(z>a&&!text.isEmpty()) out.add(new Cue(a,z,text));
                } catch(RuntimeException ignored) {} break;
            }
        }
        out.sort(Comparator.comparingLong(Cue::start)); return out;
    }
    static List<Clip> plan(long duration,long length,int count,List<Cue> cues) {
        if(duration<=0||length<=0||count<=0) throw new IllegalArgumentException("Durasi tidak valid");
        length=Math.min(length,duration);
        List<Clip> candidates=new ArrayList<>(), result=new ArrayList<>();
        for(int i=0;i<cues.size();i++) {
            Cue c=cues.get(i); long a=c.start(); if(a<0||a>=duration||duration-a<Math.min(10000,length))continue;
            long z=Math.min(duration,a+length); int score=0; long last=a;
            for(int j=i;j<cues.size()&&cues.get(j).start()<z;j++) {
                Cue x=cues.get(j); if(x.end()<=z)last=Math.max(last,x.end());
                String t=x.text().toLowerCase(Locale.ROOT);
                score+=Math.min(20,t.split("\\s+").length);
                if(t.matches(".*\\b(kenapa|mengapa|ternyata|rahasia|penting|fakta|cara|why|how|secret|because|actually)\\b.*")) score+=12;
                if(t.contains("?"))score+=5;
            }
            if(last-a>=length*0.75) z=last;
            candidates.add(new Clip(a,z,score));
        }
        candidates.sort(Comparator.comparingInt(Clip::score).reversed().thenComparingLong(Clip::start));
        for(Clip c:candidates) { if(result.size()>=count)break; if(free(c,result))result.add(c); }
        for(long a=0;a<duration && result.size()<count;a+=length) {
            long z=Math.min(a+length,duration); Clip c=new Clip(a,z,0);
            if(z-a>=Math.min(length,10000)&&free(c,result))result.add(c);
        }
        return result;
    }
    static boolean free(Clip c,List<Clip> list){for(Clip x:list)if(c.start()<x.end()&&x.start()<c.end())return false;return true;}
}
