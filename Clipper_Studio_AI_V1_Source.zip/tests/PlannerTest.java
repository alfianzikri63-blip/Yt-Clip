package com.clipper.studio;
import java.util.*;
public class PlannerTest {
  public static void main(String[] args){
    var c=Planner.parse("1\r\n00:00:05,100 --> 00:00:10,000\r\nKenapa ini penting?\r\n\r\n2\n00:00:20,000 --> 00:00:29,000\nFakta menarik!");
    if(c.size()!=2||c.get(0).start()!=5100)throw new AssertionError("SRT");
    var clips=Planner.plan(120000,30000,3,c);
    if(clips.size()!=3)throw new AssertionError("count");
    for(int i=0;i<clips.size();i++){var x=clips.get(i); if(x.start()<0||x.end()>120000||x.end()<=x.start())throw new AssertionError("bounds");for(int j=0;j<i;j++)if(!Planner.free(x,List.of(clips.get(j))))throw new AssertionError("overlap");}
    if(Planner.plan(5000,30000,5,List.of()).size()!=1)throw new AssertionError("short video");
    System.out.println("Planner tests passed");
  }
}
