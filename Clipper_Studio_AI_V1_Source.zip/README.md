# Clipper Studio AI V1.0 TEST

Prototype Android untuk menguji render clip pendek secara lokal dengan AndroidX Media3 Transformer (H.264/AAC, MP4). Min Android 10. Tidak membutuhkan secret GitHub atau API key.

## Build APK
1. Buat repository GitHub kosong, misalnya `ClipperStudioAI`.
2. Ekstrak ZIP dan upload seluruh ISI folder ke root repository (termasuk folder tersembunyi `.github`). Commit ke `main`.
3. Actions > Build Clipper Studio APK > Run workflow (atau otomatis ketika push ke main).
4. Setelah build hijau, buka run dan unduh artifact `Clipper-Studio-V1-APK`; ekstrak APK debug dan instal pada HP uji.
5. Untuk build lokal: JDK 17, Android SDK 35 dan Gradle 8.9, jalankan `gradle :app:assembleDebug`.

## Uji pertama
- Gunakan video asli milik sendiri berdurasi 1–3 menit, MP4 H.264/AAC SDR. Centang hak penggunaan.
- Tempel link YouTube publik: app memeriksa metadata melalui oEmbed; **bukan downloader YouTube**. Pilih file asli/hasil ekspor yang sah dari HP. Direct HTTPS URL file video juga dapat diimpor (tanpa redirect, maksimum 1 GB, timeout koneksi/baca).
- Pilih 1 klip, 15 detik, 720p, 9:16. Center crop untuk full screen; Fit untuk menjaga seluruh gambar. Mulai dengan manual atau batch.
- Tekan render dan biarkan aplikasi terbuka. Hasil ada di Galeri > Movies/ClipperStudio. Tombol hasil memutar video.
- Untuk subtitle, impor SRT UTF-8 dengan timestamp absolut sesuai video setelah sumber dipilih. Planner memberi skor heuristik berdasarkan kata dan pertanyaan, lalu memilih rentang tidak tumpang tindih. Tanpa SRT, batch memotong berurutan. Jumlah bisa lebih sedikit apabila durasi tidak mencukupi. Teks dibakar per cue, hingga tiga baris; belum word highlight.
- Bila gagal, catat teks error dan jenis/codec sumber. Coba 720p/Fit atau MP4 SDR lain.

## Batas V1
Tidak ada unduhan video dari halaman YouTube, transkripsi Whisper otomatis, AI generatif/viral score, tracking wajah, split screen atau resume persisten. Branding AI adalah nama proyek, bukan klaim bahwa heuristik adalah model AI. Render menggunakan encoder HP, resolusi aktual bisa bergantung codec. UI harus tetap aktif; membatalkan hanya menghapus hasil yang belum tersimpan. Tidak ada upload file lokal ke server; URL YouTube dikirim ke endpoint metadata YouTube. Tidak ada tes APK/device di lingkungan pembuatan ZIP; workflow melakukan kompilasi dan tes planner.
